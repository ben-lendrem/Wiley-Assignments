USE numbergame;

INSERT INTO game (answer,numGuesses,finished)
VALUES (6937,0,0);

INSERT INTO game (answer,numGuesses,finished)
VALUES (2741,0,0);

INSERT INTO game (answer,numGuesses,finished)
VALUES (1962,0,0);